﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDomain.Models
{
    public class TransactionReportItem
    {
        public int TransactionId { get; set; }
        public string AccountId { get; set; }
        public string AccountType { get; set; } 
        public string TransactionType { get; set; } 
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
    }
}
