﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Banking.Web.Filters
{
    
    public class SessionRoleAuthorizeAttribute : ActionFilterAttribute
    {
        private readonly string _requiredRole;

        public SessionRoleAuthorizeAttribute(string requiredRole)
        {
            _requiredRole = requiredRole;
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var role = filterContext.HttpContext.Session["Role"]?.ToString();
            if (role != _requiredRole)
            {
                filterContext.Result = new RedirectResult("~/Error/AccessDenied");
            }
        }
    }
}