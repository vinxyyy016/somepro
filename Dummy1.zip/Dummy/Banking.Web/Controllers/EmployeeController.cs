﻿using Banking.Web.Filters;
using Banking.Web.Models;
using BankingAppDataAccess;
using BankingAppDomain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Banking.Web.Controllers
{
    public class EmployeeController : Controller
    {

        private readonly LoginService _loginservice = new LoginService();
        private readonly ManagerService _managerservice = new ManagerService();
        private readonly CustomerService _customerservice = new CustomerService();
        private readonly AccountService _accountservice = new AccountService();
        private readonly TransactionService _trans = new TransactionService();
        private readonly EmployeeService _emp = new EmployeeService();
        // GET: Employee
        [HttpGet]
        public ActionResult Login()
        {
            if (Session["Role"] != null)
            {
                return RedirectToAction("Dashboard", $"{Session["Role"].ToString()}");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserLogin u)
        {
            
            u.Role = ControllerContext.RouteData.Values["controller"]?.ToString(); ;
            if (_loginservice.ValidateEmployee(u))
            {
                UserLogin us = _managerservice.GetLogDet(u.UserName, u.PasswordHash);
                Session["EmployeeUser"] = us.UserName;
                Session["UserID"] = us.ReferenceID;
                Session["Role"] = us.Role;
                return RedirectToAction("Dashboard");
            }

            ViewBag.Error = "Invalid Credentials or Inactive Account.";
            return View();
        }
        [SessionRoleAuthorize("Employee")]
        public ActionResult Dashboard()
        {

            if (Session["EmployeeUser"] == null)
            {
                return RedirectToAction("Login");
            }
            else if (Session["Role"] != null)
            {
                return RedirectToAction("Dashboard", $"{Session["Role"].ToString()}");
            }
            var data = _emp.GetDashboardSummary();
            ViewBag.TotalCustomers = data.cust;
            ViewBag.TotalAccounts = data.acc;
            ViewBag.TotalLoans = data.loan;
            ViewBag.Employee = Session["Employeeuser"].ToString();
            return View();
        }

        
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
    }
}