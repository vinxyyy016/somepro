﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BankProjectBusinessLogic;
using BankProjectBusinessLogic.services;
using BankProject_DataAccess;

namespace BankProject.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        private LoginService _loginService = new LoginService();
        
        public ActionResult Login(string UserName, string Password, string UserRole)
        {
            switch (UserRole)
            {
                case "Manager":
                    if (_loginService.LoginManager(UserName, Password))
                        return RedirectToRoute(new {Controller="Manager",Action="ManagerDashboard"});
                    else
                        ViewData["err"] = "invalid credentials";
                    break;

                case "Employee":
                    if (_loginService.LoginEmployee(UserName, Password))
                        return RedirectToRoute(new { Controller = "Employee", Action = "EmployeeDashboard" });
                    else
                        ViewData["err"] = "invalid credentials";
                    break;
                case "Customer":
                    if (_loginService.LoginCustomer(UserName, Password))
                        return RedirectToRoute(new { Controller = "Customer", Action = "CustomerDashboard" });
                    else
                        ViewData["err"] = "invalid credentials";
                    break;
            }
            return View();
        }
    }
}