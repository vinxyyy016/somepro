﻿using Banking.Web.Filters;
using BankingAppDataAccess;
using BankingAppDomain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Interop;

namespace Banking.Web.Controllers
{
    public class CustomerController : Controller
    {
        private readonly LoginService _loginservice = new LoginService();
        private readonly ManagerService _managerservice = new ManagerService();
        private readonly CustomerService _customerservice = new CustomerService();
        private readonly AccountService _accountservice = new AccountService();
        private readonly TransactionService _trans = new TransactionService();
        private readonly EmployeeService _emp = new EmployeeService();

        [HttpGet]
        public ActionResult Login()
        {
            if (Session["Role"] != null)
            {
                return RedirectToAction("Dashboard", $"{Session["Role"].ToString()}");
            }
            return View();
        }

        [HttpPost]

        public ActionResult Login(UserLogin u)
        {

            u.Role = ControllerContext.RouteData.Values["controller"]?.ToString(); ;
            if (_loginservice.ValidateCustomer(u))
            {
                UserLogin us = _managerservice.GetLogDet(u.UserName, u.PasswordHash);
                Session["CustomerUser"] = us.UserName;
                Session["UserID"] = us.ReferenceID;
                Session["Role"] = us.Role;
                return RedirectToAction("Dashboard");
            }

            ViewBag.Error = "Invalid Credentials or Inactive Account.";
            return View();
        }

        [HttpGet]
        [SessionRoleAuthorize("Customer")]
        public ActionResult Dashboard()
        {
            string id = Session["UserID"].ToString();
            var data = _customerservice.GetCustomerAccounts(id);
            if (data == null)
                return HttpNotFound();
            return View(data);
        }

        [HttpGet]
        [SessionRoleAuthorize("Customer")]
        public ActionResult BankTransfer()
        {

            var acctrans = _accountservice.GetAllAccTransById(Session["UserId"].ToString());
            ViewBag.AccountId = Session["UserId"].ToString();
            return View(acctrans);
        }

        [HttpPost]
        public ActionResult BankTransfer(string fromAccountId, string toAccountId, decimal amount)
        
        
        {
            string id = Session["UserID"].ToString();
            try
            {
                AccTransaction t = new AccTransaction
                {
                    FromSBAcc = fromAccountId,
                    ToSBAcc = toAccountId,
                    Amount = amount
                };
                string res = _trans.PerformBankTransfer(t, id);
                TempData["Message"] = res;
            }
            catch (Exception ex)
            {
                TempData["Message"] = ex.Message;
                
            }
            var acctrans = _accountservice.GetAllAccTransById(Session["UserId"].ToString());
            ViewBag.AccountId = Session["UserId"].ToString();
            return View(acctrans);
          
        }
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }

    }
}