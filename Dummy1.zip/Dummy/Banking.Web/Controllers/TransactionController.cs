﻿using Banking.Web.Models;
using BankingAppDataAccess;
using BankingAppDomain.Models;
using BankingAppDomain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Banking.Web.Controllers
{
    public class TransactionController : Controller
    {
        // GET: Transaction
        private TransactionService _trans = new TransactionService();
        private AccountService _accService = new AccountService();
        [HttpGet]
        public ActionResult Savings(string accountId)
        {
            var txList = _trans.GetSavingsTransactions(accountId);
            ViewBag.AccountId = accountId;
            ViewBag.CanAddTransaction = true; // default true; can disable for customer later
            return View($"~/Views/{Session["Role"]}/SavingsTransactions.cshtml", txList);
        }

        [HttpPost]
        public ActionResult Add(TransactionModel model)
        {
            if (model == null || string.IsNullOrEmpty(model.AccountId))
            {
                TempData["Message"] = "Invalid transaction request.";
                return RedirectToAction("Accounts", "Shared");
            }
 
            var msg = _trans.AddSavingsTransaction(model);
            TempData["Message"] = msg;
 
            return RedirectToAction("Savings", new { accountId = model.AccountId });
        }

        [HttpGet]
        public ActionResult FixedDeposit(string fdId, bool canAdd = true)
        {
            if (string.IsNullOrEmpty(fdId))
                return RedirectToAction("Accounts", "Shared");

            var txList = _trans.GetFDTransactions(fdId);
            var compute = _trans.ComputeFDPayout(fdId, DateTime.Now);

            ViewBag.AccountId = fdId;
            ViewBag.CanAddTransaction = canAdd;
            ViewBag.FDComputation = compute;

            return View($"~/Views/{Session["Role"]}/FDTransactions.cshtml", txList);
        }

        [HttpPost]
        public ActionResult AddFixedDepositAction(string fdId, string action, string creditSBAccountId = null, decimal? penaltyPercent = null)
        {
            if (string.IsNullOrEmpty(fdId))
            {
                TempData["Message"] = "Invalid FD Account ID.";
                return RedirectToAction("Accounts", "Shared");
            }

            string msg = _trans.ProcessFDClosure(fdId, action, creditSBAccountId, penaltyPercent);
            TempData["Message"] = msg;

            return RedirectToAction("FixedDeposit", new { fdId });
        }
        [HttpGet]
        public ActionResult Loan(string lnId, bool canAdd = true)
        {
            if (string.IsNullOrEmpty(lnId))
                return RedirectToAction("Accounts", "Shared");
            LoanTransactionModel ln = new LoanTransactionModel();
            ln.LoanAccount = _accService.GetLoanAcc(lnId);
            ln.LoanTransactions = _trans.GetLoanTransactions(lnId);
            ViewBag.AccountId = lnId;
            ViewBag.CanAddTransaction = canAdd;
            return View($"~/Views/{Session["Role"]}/LoanTransactions.cshtml", ln);
        }

        [HttpPost]
        public ActionResult AddLoanPayment(string lnId, decimal amount,string transactionType,string toAccountId)
        {
            if (string.IsNullOrEmpty(lnId))
            {
                TempData["Message"] = "Invalid Loan Account ID.";
                return RedirectToAction("Accounts", "Shared");
            }

            var msg = _trans.AddLoanPayment(lnId, amount, transactionType,toAccountId);
            TempData["Message"] = msg;
            return RedirectToAction("Loan", new { lnId });
        }
    }
}