﻿using Banking.Web.Models;
using BankingAppDataAccess;
using BankingAppDomain.Models;
using BankingAppDomain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Banking.Web.Filters;

namespace Banking.Web.Controllers
{
    
    public class ManagerController : Controller
    {
        // GET: Manager
        private readonly LoginService _loginservice = new LoginService();
        private readonly ManagerService _managerservice = new ManagerService();
        private readonly CustomerService _customerservice = new CustomerService();
        private readonly AccountService _accountservice = new AccountService();
        private TransactionService _trans = new TransactionService();

        [HttpGet]
        public ActionResult Login()
        {
            if (Session["Role"] != null)
            {
                return RedirectToAction("Dashboard", $"{Session["Role"].ToString()}");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserLogin u)
        {

            u.Role = ControllerContext.RouteData.Values["controller"]?.ToString(); ;
            if (_loginservice.ValidateManager(u))
            {
                UserLogin us = _managerservice.GetLogDet(u.UserName, u.PasswordHash);
                Session["ManagerUser"] = us.UserName;
                Session["UserID"] = us.ReferenceID;
                Session["Role"] = us.Role;
                    return RedirectToAction("Dashboard");
            }

            ViewBag.Error = "Invalid Credentials or Inactive Account.";
            return View();
        }
        [SessionRoleAuthorize("Manager")]
        public ActionResult Dashboard()
        {

            if (Session["ManagerUser"] == null)
            {
                return RedirectToAction("Login");
            }
            var data = _managerservice.GetDashboardSummary();
            ViewBag.TotalCustomers = data.cust;
            ViewBag.TotalEmployees = data.emp;
            ViewBag.TotalAccounts = data.acc;
            ViewBag.TotalLoans = data.loan;
            ViewBag.Manager = Session["Manageruser"].ToString();
            return View();
        }

        public ActionResult Employees()
        {
            var list = _managerservice.GetAllEmployees();
            return View(list);
        }

        [HttpGet]
        public ActionResult AddEmployee()
        {
            var list = _managerservice.GetAllDepartments();
            ViewBag.Departments = new SelectList(list, "DepartmentID", "DepartmentName");
            return View();
        }

        [HttpPost]
        public ActionResult AddEmployee(EmployeeUserModel e)
        {
            
                e.Employee.Status = "Active";
                string empid = _managerservice.AddEmployee(e.Employee);
                e.UserLogin.ReferenceID = empid;
                e.UserLogin.Role = "Employee";
                e.UserLogin.Status = "Active";
                string addemp = _managerservice.AddUserLogin(e.UserLogin);
                return RedirectToAction("Employees");

        }


        [HttpPost]
        public ActionResult ChangeEmployeeStatus(string custId, string status)
        {
            string msg = _managerservice.ChangeEmployeeStatus(custId, status);
            TempData["Message"] = msg;
            return RedirectToAction("Employees");
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }

        


        public ActionResult ViewAccount(string id)
        {


            var data = _customerservice.GetCustomerAccounts(id);
            if (data == null)
                return HttpNotFound();

            return View(data);
        }



    }
}