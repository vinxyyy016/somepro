﻿using BankProject_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjectBusinessLogic.services
{
    public class LoginService
    {
        BankProjectEntities1 bp = new BankProjectEntities1();
        public bool LoginManager(string username, string password)
        {
            return bp.LoginDatas.Any(b => b.UserName== username && b.Password == password);
        }

        public bool LoginEmployee(string username, string password)
        {
            return bp.LoginDatas.Any(b => b.UserName == username && b.Password == password && b.UserRole == "Employee");
        }

        public bool LoginCustomer(string username, string password)
        {
            return bp.LoginDatas.Any(b => b.UserName == username && b.Password == password && b.UserRole == "Customer");
        }
    }
}
