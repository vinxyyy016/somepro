﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
namespace Banking.Web.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/lib/jquery").Include(
                        "~/lib/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/lib/jquery").Include(
                        "~/lib/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/lib/bootstrap").Include(
                      "~/lib/bootstrap.bundle.min.js"));

            
        }
    }
}