﻿using Banking.Web.Models;
using BankingAppDomain.Models;
using BankingAppDomain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Banking.Web.Controllers
{
    public class SharedController : Controller
    {

        private readonly LoginService _loginservice = new LoginService();
        private readonly ManagerService _managerservice = new ManagerService();
        private readonly CustomerService _customerservice = new CustomerService();
        private readonly AccountService _accountservice = new AccountService();
        private readonly TransactionService _trans = new TransactionService();
        public ActionResult ViewCustomerAccounts(string id)
        {
            var data = _customerservice.GetCustomerAccounts(id);
            if (data == null)
                return HttpNotFound();

            return View($"~/Views/{Session["Role"]}/ViewCustomerAccounts.cshtml",data);
        }

        
        public ActionResult Customers()
        {
            var list = _managerservice.GetAllCustomers();
            return View($"~/Views/{Session["Role"]}/Customers.cshtml",list);
        }

        [HttpGet]
        public ActionResult AddCustomer()
        {
            return View($"~/Views/{Session["Role"]}/AddCustomer.cshtml");
        }

        [HttpPost]
        public ActionResult AddCustomer(CustomerUserModel e)
        {
            try
            {


                e.Customer.Status = "Active";
                string custid = _managerservice.AddCustomer(e.Customer);
                
                e.UserLogin.ReferenceID = custid;
                e.UserLogin.Role = "Customer";
                e.UserLogin.Status = "Active";

                if (ModelState.IsValid)
                {
                    e.Customer.Status = "Active";

                    string addcust = _managerservice.AddUserLogin(e.UserLogin);
                    return RedirectToAction("Customers");
                }
                return View($"~/Views/{Session["Role"]}/AddCustomer.cshtml");
            }
            catch(Exception ex)
            {
                TempData["Message"] = ex.Message;
                return View($"~/Views/{Session["Role"]}/AddCustomer.cshtml");
            }
        }
        [HttpPost]
        public ActionResult ChangeCustomerStatus(string custId, string status)
        {
            string msg = _managerservice.ChangeCustomerStatus(custId, status);
            TempData["Message"] = msg;
            return RedirectToAction("Customers");
        }

        public ActionResult Accounts()
        {
            var customers = _managerservice.GetAllCustomers()
                                           .Where(c => c.Status == "Active")
                                           .ToList();

            ViewBag.CustomerList = new SelectList(customers, "CustomerID", "CustomerName");
            var allAccounts = _accountservice.GetAllAccounts();



            return View($"~/Views/{Session["Role"]}/Accounts.cshtml", allAccounts);

        }
        [HttpGet]
        public ActionResult Accounts(string type = null, string status = null, string customerId = null)
        {

            var allAccounts = _accountservice.GetAllAccounts();

            // filters
            if (!string.IsNullOrEmpty(type))
                allAccounts = allAccounts.Where(a => a.AccountType == type).ToList();

            if (!string.IsNullOrEmpty(status))
                allAccounts = allAccounts.Where(a => a.Status == status).ToList();

            if (!string.IsNullOrEmpty(customerId))
                allAccounts = allAccounts.Where(a => a.CustomerID == customerId).ToList();

            // dropdowns for filters
            var customers = _managerservice.GetAllCustomers()
                                                .Where(c => c.Status == "Active")
                                                .ToList();

            ViewBag.CustomerList = new SelectList(customers, "CustomerID", "CustomerName");
            ViewBag.SelectedType = type;
            ViewBag.SelectedStatus = status;
            ViewBag.SelectedCustomer = customerId;

            return View($"~/Views/{Session["Role"]}/Accounts.cshtml", allAccounts);
        }


        [HttpPost]
        public ActionResult CloseAccount(string accountId)
        {
            try { 
            _accountservice.CloseAccount(accountId);

            TempData["Message"] = $"Account {accountId} has been closed successfully.";
            return RedirectToAction("Accounts"); }
        catch(Exception ex)
            {
                TempData["Message"] = ex.Message;
                return RedirectToAction("Accounts");
            }
        }

        [HttpGet]
        public ActionResult AddAccount()
        {
            var activeCustomers = _managerservice.GetAllCustomers()
                                           .Where(c => c.Status == "Active")
                                            .Select(c => new
                                            {
                                                c.CustomerID,
                                                c.CustomerName,
                                                Age = c.DOB.HasValue ?
                                                    (int)((DateTime.Now - c.DOB.Value).TotalDays / 365.25) : 0
                                            })
                                            .ToList();

            ViewBag.CustomerList = new SelectList(activeCustomers, "CustomerID", "CustomerName");

            ViewBag.CustomerAges = Newtonsoft.Json.JsonConvert.SerializeObject(activeCustomers.ToDictionary(c => c.CustomerID, c => c.Age));

            return View($"~/Views/{Session["Role"]}/AddAccount.cshtml");
        }
        [HttpPost]
        public ActionResult AddAccount(AccountTypeModel model)
        {
            model.Account.OpenedBy = Session["UserID"]?.ToString() ?? "M0001";
            model.Account.OpenedByRole = Session["Role"]?.ToString() ?? "MAN";
            try
            {
                string msg = _accountservice.CreateAccount(model);
                if (msg != null)
                {


                    TempData["Message"] = msg;
                    return RedirectToAction("Accounts");
                }



                var activeCustomers = _managerservice.GetAllCustomers()
                                               .Where(c => c.Status == "Active")
                                               .ToList();

                ViewBag.CustomerList = new SelectList(activeCustomers, "CustomerID", "CustomerName");
                return View($"~/Views/{Session["Role"]}/AddAccount.cshtml", model);
            }
            catch(Exception ex)
            {
                
                TempData["Message"] = ex.Message;
                return RedirectToAction("AddAccount");
            }
        }
    }
}