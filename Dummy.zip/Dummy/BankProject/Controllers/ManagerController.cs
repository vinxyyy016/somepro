﻿using BankProject.Models;
using BankProject_DataAccess;
using BankProjectBusinessLogic.services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BankProject.Controllers
{
    public class ManagerController : Controller
    {
        // GET: Manager
        private ManagerService _managerService = new ManagerService();
        public ActionResult ManagerDashboard()
        {
            ViewBag.PartialView = "_Welcome"; // default partial
            return View();
        }

        [HttpGet]
        public ActionResult AddEmployee()
        {
            AddEmployee a = new AddEmployee()
            {
                Employee = new Employee(),
                LoginData = new LoginData()
            };

            ViewBag.PartialView = "AddEmployee";
            return View("ManagerDashboard",a);
        }

        [HttpPost]
        public ActionResult AddEmployee(AddEmployee ae)
        {
            if (ModelState.IsValid)
            {
                // Save employee logic here
                bool success = _managerService.AddEmployee(ae.Employee,ae.LoginData);
                if (success)
                {
                    TempData["SuccessMessage"] = "Employee added successfully!";
                    return RedirectToAction("ManagerDashboard");
                }
                    
                else
                    ViewBag.Message = "Failed to add employee.";
            }

            ViewBag.PartialView = "AddEmployee";
            return View("ManagerDashboard", ae);
        }

        [HttpGet]
        public ActionResult DeleteEmployee()
        {
            var employees=_managerService.GetEmployees();
            ViewBag.PartialView = "DeleteEmployee";
            return View("ManagerDashboard", employees);
        }

        [HttpPost]
        public ActionResult DeleteEmployee(string Id)
        {
                // Save employee logic here
                bool success = _managerService.DeleteEmployee(Id);
                if (success)
                {
                    TempData["SuccessMessage"] = "Employee deleted successfully!";
                    return RedirectToAction("ManagerDashboard");
                }

                else
                    ViewBag.Message = "Failed to delete employee.";
            return View("ManagerDashboard");
        }

        [HttpGet]
        public ActionResult AddCustomer()
        {
            AddCustomer c=new AddCustomer()
            {
                Customer=new Customer(),
                LoginData = new LoginData()
            };

            ViewBag.PartialView = "AddCustomer";
            return View("ManagerDashboard", c);
        }

        [HttpPost]
        public ActionResult AddCustomer(AddCustomer ac)
        {
            if (ModelState.IsValid)
            {
                // Save employee logic here
                bool success = _managerService.AddCustomer(ac.Customer, ac.LoginData);
                if (success)
                {
                    TempData["SuccessMessage"] = "Customer added successfully!";
                    return RedirectToAction("ManagerDashboard");
                }

                else
                    ViewBag.Message = "Failed to add customer.";
            }

            ViewBag.PartialView = "AddCustomer";
            return View("ManagerDashboard", ac);
        }

        [HttpGet]
        public ActionResult DeleteCustomer()
        {
            var customers = _managerService.GetCustomers();
            ViewBag.PartialView = "DeleteCustomer";
            return View("ManagerDashboard", customers);
        }

        [HttpPost]
        public ActionResult DeleteCustomer(string Id)
        {
            // Save employee logic here
            bool success = _managerService.DeleteCustomer(Id);
            if (success)
            {
                TempData["SuccessMessage"] = "Customer deleted successfully!";
                return RedirectToAction("ManagerDashboard");
            }

            else
                ViewBag.Message = "Failed to delete customer.";
            return View("ManagerDashboard");
        }
    }
}