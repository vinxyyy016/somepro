﻿using BankingAppDataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Banking.Web.Models
{
    public class CustomerUserModel
    {
        public BankingAppDataAccess.Customer Customer{ get; set; }
        public BankingAppDataAccess.UserLogin UserLogin { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password
        {
            get => UserLogin?.PasswordHash;
            set
            {
                if (UserLogin == null) UserLogin = new UserLogin();
                UserLogin.PasswordHash = value;
            }
        }



        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfPass { get; set; }

    }
}