﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDataAccess.Repositories
{
    public class EmployeeRepository
    {
        private readonly BANKINGEntities db = new BANKINGEntities();
        public List<Employee> GetEmployees()
        {
            List<Employee> em = db.Employees.ToList();
            return em;
        }

        public bool GetEmployeeById(string id)
        {
            return db.Employees.Any(e => e.EmployeeID == id);
        }

        public bool IsPanExist(string pan)
        {
            return db.Employees.Any(e => e.PAN == pan)|| db.Managers.Any(e => e.PAN == pan) || db.Customers.Any(e => e.PAN == pan);
        }

        public void AddEmployee(Employee e)
        {
            db.Employees.Add(e);
            db.SaveChanges();
        }

        public bool EmployeeIdExists(string empId)
        {
            return db.Employees.Any(e => e.EmployeeID == empId);
        }

        public Employee GetEmployeeFromId(string empId)
        {
            return db.Employees.FirstOrDefault(e => e.EmployeeID == empId);
        }

        public bool UpdateEmployeeStatus(string empId, string newStatus)
        {
            try
            {
                var cust = db.Employees.FirstOrDefault(c => c.EmployeeID == empId);
                if (cust != null)
                {
                    cust.Status = newStatus;
                    db.SaveChanges();
                    return true;
                }
                return false;
            }

            catch (DbEntityValidationException ex)
            {
                var errorMessages = new List<string>();

                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var error in validationErrors.ValidationErrors)
                    {
                        errorMessages.Add($"Property: {error.PropertyName}, Error: {error.ErrorMessage}");
                    }
                }

                var fullErrorMessage = string.Join("; ", errorMessages);
                var exceptionMessage = $"{ex.Message} Validation Errors: {fullErrorMessage}";

                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
        }
    }
}
