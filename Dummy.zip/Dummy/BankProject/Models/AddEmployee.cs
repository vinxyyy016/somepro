﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BankProject_DataAccess;

namespace BankProject.Models
{
    public class AddEmployee
    {
        public Employee Employee { get; set; }
        public LoginData LoginData { get; set; }
    }
}