﻿using BankProject_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankProject.Models
{
    public class AddCustomer
    {
        public Customer Customer { get; set; }
        public LoginData LoginData { get; set; }
    }
}