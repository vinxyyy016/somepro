﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankingAppDataAccess;
using BankingAppDataAccess.Repositories;

namespace BankingAppDomain.Services
{
    public class LoginService
    {
        private readonly BANKINGEntities _db = new BANKINGEntities();
        private readonly UserLoginRepository _ul = new UserLoginRepository();

        public bool ValidateManager(UserLogin u)
        {
            return _ul.ValUser(u);
        }

        public bool ValidateEmployee(UserLogin u)
        {
            return _ul.ValUser(u);
        }

        public bool ValidateCustomer(UserLogin u)
        {
            return _ul.ValUser(u);
        }
    }
}
