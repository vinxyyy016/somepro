﻿using BankingAppDataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDomain.Services
{
    public class EmployeeService
    {
        private readonly ManagerRepository _repo = new ManagerRepository();
        public (int cust,  int acc, int loan) GetDashboardSummary()
        {
            int cust = _repo.GetCustomerCount();
            
            int acc = _repo.GetAccountCount();
            int loan = _repo.GetLoanCount();

            return (cust, acc, loan);
        }
    }
}
