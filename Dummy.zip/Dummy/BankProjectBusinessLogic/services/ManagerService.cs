﻿using BankProject_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjectBusinessLogic.services
{
    public class ManagerService
    {
        BankProjectEntities1 bp = new BankProjectEntities1();

        private readonly Random _random = new Random();

       
        public bool AddEmployee(Employee e, LoginData ld)
        {
            try
            {
                e.Approval_Status = "Yes";
                bp.Employees.Add(e);
                ld.UserRole = "Employee";
                ld.ReferenceID = e.EmployeeId;
                int ra = _random.Next(1001, 9999);
                ld.UserID = ra.ToString();
                bp.LoginDatas.Add(ld);
                bp.SaveChanges();
                return true;
            }
            catch(Exception ex) 
            {
                Console.WriteLine("EF Error: " + ex.Message);
                return false;
            }
                          
        }
        
        //public bool UpdateEmployee(string EmpId)
        //{
        //    Employee e = bp.Employees.Find(EmpId);
        //    if (e != null && e.Approval_Status=="No")
        //    {
        //        e.Approval_Status = "Yes";
        //        bp.SaveChanges();
        //        return true;
        //    }
        //    else
        //        return false;
        //}

        public List<Employee> GetEmployees()
        {
            return bp.Employees.ToList();
        }

        public bool DeleteEmployee(string EmpId)
        {
            Employee e=bp.Employees.Find(EmpId);
            LoginData login = bp.LoginDatas.FirstOrDefault(l => l.ReferenceID == EmpId);

            if (e != null)
            {
                e.Approval_Status = "NO";
                if (login != null)
                {
                    bp.LoginDatas.Remove(login);
                }
                bp.SaveChanges();
                return true;    
            }
            else
                return false;
        }

        public bool AddCustomer(Customer c,LoginData ld)
        {
            try
            {
                c.Approval_Status = "Yes";
                bp.Customers.Add(c);
                ld.UserRole = "Customer";
                ld.ReferenceID = c.CustomerId;
                int ra = _random.Next(1001, 9999);
                ld.UserID = ra.ToString();
                bp.LoginDatas.Add(ld);
                bp.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }


        //public bool UpdateCustomer(string CustID)
        //{
        //    Customer cust = bp.Customers.Find(CustID);
        //    if (cust != null && cust.Approval_Status == "No")
        //    {
        //        cust.Approval_Status = "Yes";
        //        bp.SaveChanges();
        //        return true;
        //    }
        //    else
        //        return false;
        //}

        public List<Customer> GetCustomers()
        {
            return bp.Customers.ToList();
        }

        public bool DeleteCustomer(string CustID)
        {
            Customer cust = bp.Customers.Find(CustID);
            LoginData login = bp.LoginDatas.FirstOrDefault(l => l.ReferenceID == CustID);
            if (cust != null)
            {
                cust.Approval_Status = "NO";
                if (login != null)
                {
                    bp.LoginDatas.Remove(login);
                }
                bp.SaveChanges();
                return true;
            }
            else
                return false;
        }
    }
}
