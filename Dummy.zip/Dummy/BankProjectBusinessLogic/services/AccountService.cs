﻿using BankProject_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProjectBusinessLogic.services
{
    public  class AccountService
    {
        BankProjectEntities1 bp = new BankProjectEntities1();

        public bool AddSavingsAccount(Account a,SavingsAccount sa)
        {
            try
            {
                a.Opened_on = DateTime.Now;
                a.AccountStatus = "Active";
                bp.Accounts.Add(a);
                sa.SBAccountId = a.AccountId;
                sa.CustomerId = a.CustomerId;
                bp.SavingsAccounts.Add(sa);
                bp.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool AddFixedDepositAccount(Account a, FixedDeposit fd)
        {
            try
            {
                a.Opened_on = DateTime.Now;
                a.AccountStatus = "Active";
                bp.Accounts.Add(a);
                fd.FDAccountId = a.AccountId;
                fd.Customerid = a.CustomerId;
                fd.Opened_on = a.Opened_on;
                bp.FixedDeposits.Add(fd);
                bp.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool AddLoanAccount(Account a, LoanAccount la)
        {
            try
            {
                a.Opened_on = DateTime.Now;
                a.AccountStatus = "Active";
                bp.Accounts.Add(a);
                la.LNAccountId = a.AccountId;
                la.CustomerId = a.CustomerId;
                la.StartDate = a.Opened_on;
                bp.LoanAccounts.Add(la);
                bp.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
