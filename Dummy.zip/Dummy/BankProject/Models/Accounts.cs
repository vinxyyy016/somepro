﻿using BankProject_DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankProject.Models
{
    public class Accounts
    {
        public Account Account { get; set; }
        public SavingsAccount SavingsAccount { get; set; }
        public FixedDeposit FixedDeposit { get; set; }
        public LoanAccount LoanAccount { get; set; }
    }
}