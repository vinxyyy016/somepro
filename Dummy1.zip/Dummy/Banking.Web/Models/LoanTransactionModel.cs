﻿using BankingAppDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Banking.Web.Models
{
    public class LoanTransactionModel
    {
        public LoanAccount LoanAccount { get; set; }
        public List<LoanTransaction> LoanTransactions { get; set; }
    }
}