﻿using BankProject.Models;
using BankProject_DataAccess;
using BankProjectBusinessLogic.services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace BankProject.Controllers
{
    public class AccountsController : Controller
    {
        private AccountService _accountService=new AccountService();
        // GET: Accounts
        public ActionResult AccountDashboard()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AddSavingsAccount()
        {
            Accounts a=new Accounts()
            {
                Account=new Account(),
                SavingsAccount=new SavingsAccount()
            };
            ViewBag.PartialView = "AddSavingsAccount";
            return View("AddSavingsAccount", a);
            
        }

        [HttpPost]
        public ActionResult AddSavingsAccount(Accounts a)
        {
            if (ModelState.IsValid)
            {
                
                bool success = _accountService.AddSavingsAccount(a.Account,a.SavingsAccount);
                if (success)
                {
                    TempData["SuccessMessage"] = "Savings account added successfully!";
                    return RedirectToAction("ManagerDashboard","Manager");
                }

                else
                    ViewBag.Message = "Failed to add savings account.";
            }
            ViewBag.PartialView = "AddSavingsAccount";
            return View("AddSavingsAccount", a);
        }

        [HttpGet]
        public ActionResult AddFixedAccount()
        {
            Accounts a = new Accounts()
            {
                Account = new Account(),
                FixedDeposit = new FixedDeposit()
            };
            ViewBag.PartialView = "AddFixedAccount";
            return View("AddFixedAccount", a);

        }

        [HttpPost]
        public ActionResult AddFixedAccount(Accounts a)
        {
            if (ModelState.IsValid)
            {

                bool success = _accountService.AddFixedDepositAccount(a.Account, a.FixedDeposit);
                if (success)
                {
                    TempData["SuccessMessage"] = "Fixed Deposit account added successfully!";
                    return RedirectToAction("ManagerDashboard", "Manager");
                }

                else
                    ViewBag.Message = "Failed to add fixed deposit account.";
            }
            ViewBag.PartialView = "AddFixedDepositAccount";
            return View("AddFixedDepositAccount", a);
        }

        [HttpGet]
        public ActionResult AddLoanAccount()
        {
            Accounts a = new Accounts()
            {
                Account = new Account(),
                LoanAccount = new LoanAccount()
            };
            ViewBag.PartialView = "AddLoanAccount";
            return View("AddLoanAccount", a);

        }

        [HttpPost]
        public ActionResult AddLoanAccount(Accounts a)
        {
            if (ModelState.IsValid)
            {

                bool success = _accountService.AddLoanAccount(a.Account, a.LoanAccount);
                if (success)
                {
                    TempData["SuccessMessage"] = "Loan account added successfully!";
                    return RedirectToAction("ManagerDashboard", "Manager");
                }

                else
                    ViewBag.Message = "Failed to add loan account.";
            }
            ViewBag.PartialView = "AddLoanAccount";
            return View("AddLoanAccount", a);
        }
    }
}