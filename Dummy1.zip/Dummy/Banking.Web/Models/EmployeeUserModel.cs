﻿using BankingAppDataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Banking.Web.Models
{
    public class EmployeeUserModel
    {
        public BankingAppDataAccess.Employee Employee { get; set; }
        public BankingAppDataAccess.UserLogin UserLogin { get; set; }
        [Required]
        public string Password
        {
            get => UserLogin?.PasswordHash;
            set
            {
                if (UserLogin == null) UserLogin = new UserLogin();
                UserLogin.PasswordHash = value;
            }
        }



        [Required]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfPass { get; set; }
    }
}