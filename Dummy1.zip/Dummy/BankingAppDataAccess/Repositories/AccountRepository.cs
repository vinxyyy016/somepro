﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDataAccess.Repositories
{
    public class AccountRepository
    {
        private readonly BANKINGEntities db = new BANKINGEntities();

        public List<Account> GetAccountsByCustomer(string custId)
        {
            List<Account> accounts = db.Accounts.Where(a => a.CustomerID == custId).ToList();
            return accounts;
        }

        public string GetAccStatusFromCust(string id)
        {
            Account ac = db.Accounts.FirstOrDefault(c => c.AccountID == id);
            return ac.Status.ToString();
        }

        public List<Account> GetAllAccounts()
        {
            List<Account> accounts = db.Accounts.ToList();
            return accounts;
        }

        public Account GetAccountById(string accountId)
        {
            Account acc = db.Accounts.FirstOrDefault(a => a.AccountID == accountId);
            return acc;
        }

        public string AddAccount(Account a,SavingsAccount s)
        {
            db.Accounts.Add(a);
            db.SavingsAccounts.Add(s);
            db.SaveChanges();
            return a.AccountID;
        }

        public void AddSavingsAccount(SavingsAccount s)
        {
            db.SavingsAccounts.Add(s);
            db.SaveChanges();

        }

        public void AddFDAccount(Account a,FixedDepositAccount f)
        {
            db.Accounts.Add(a);
            db.FixedDepositAccounts.Add(f);
            db.SaveChanges();
        }

        public void AddLoanAccount(Account a, LoanAccount l)
        {
            db.Accounts.Add(a);
            db.LoanAccounts.Add(l);
            db.SaveChanges();
        }

        public void UpdateAccountStatus(string accountId, string status, DateTime? closedDate = null)
        {
            var acc = db.Accounts.FirstOrDefault(a => a.AccountID == accountId);
            if (acc != null)
            {
                acc.Status = status;
                if (closedDate.HasValue)
                    acc.ClosedDate = closedDate.Value;
                db.SaveChanges();
            }
        }

        public List<SavingsAccount> GetSavingsByCustomer(string custId)
        {
            List<SavingsAccount> savings = db.SavingsAccounts.Where(a => a.CustomerID == custId).ToList();
            return savings;
        }
        public SavingsAccount GetSavingsByCust(string custId)
        {
            return db.SavingsAccounts.FirstOrDefault(c => c.CustomerID == custId);
        }

        public SavingsAccount GetSavingsAccount(string id)
        {
            return db.SavingsAccounts.FirstOrDefault(c=> c.SBAccountID==id);
        }

        public List<FixedDepositAccount> GetFDByCustomer(string custId)
        {
            List < FixedDepositAccount > fixedacc = db.FixedDepositAccounts.Where(a => a.CustomerID == custId).ToList();
            return fixedacc;
        }

        public List<LoanAccount> GetLoanByCustomer(string custId)
        {
            List < LoanAccount > loan = db.LoanAccounts.Where(a => a.CustomerID == custId).ToList();
            return loan;
        }
        public List<FixedDepositAccount> GetOpenFDByCustomer(string custId)
        {
            List<FixedDepositAccount> fixedacc = db.FixedDepositAccounts.Where(a => a.CustomerID == custId && a.Account.Status == "OPEN").ToList();
            return fixedacc;
        }
        public List<LoanAccount> GetOpenLoanByCustomer(string custId)
        {
            List<LoanAccount> loan = db.LoanAccounts.Where(a => a.CustomerID == custId && a.Account.Status == "OPEN").ToList();
            return loan;
        }

        public LoanAccount GetLoanById(string id)
        {
            return db.LoanAccounts.FirstOrDefault(l => l.LNAccountID == id);
        }

        public List<AccTransaction> GetAllAccTrans(string sBAccountID)
        {
            List<AccTransaction> accTrans = db.AccTransactions
                                              .Where(t => t.FromSBAcc == sBAccountID || t.ToSBAcc == sBAccountID)
                                              .OrderByDescending(t => t.TransactionId)
                                              .ToList();
            return accTrans;
        }
    }
}
