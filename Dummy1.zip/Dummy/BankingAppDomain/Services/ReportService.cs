﻿using BankingAppDataAccess;
using BankingAppDomain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDomain.Services
{
    public class ReportService
    {
        private readonly BANKINGEntities _db = new BANKINGEntities();

        // unified query with server-side paging
        public List<TransactionReportItem> GetTransactionReport(DateTime? fromDate, DateTime? toDate,
                                                               string category = "ALL",
                                                               string customerId = null,
                                                               int page = 1, int pageSize = 100)
        {
            // Normalize dates
            DateTime from = fromDate ?? DateTime.MinValue;
            DateTime to = toDate?.Date.AddDays(1).AddTicks(-1) ?? DateTime.MaxValue;

            // Savings
            var savings = _db.SavingsTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.SBAccountID,
                    AccountType = "Savings",
                    TransactionType = t.TransactionType,
                    Amount = (decimal)t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.SavingsAccount.CustomerID,
                    CustomerName = t.SavingsAccount.Customer.CustomerName
                });

            
            var fd = _db.FixedDepositTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.FDAccountID,
                    AccountType = "Fixed Deposit",
                    TransactionType = t.TransactionType,
                    Amount = t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.FixedDepositAccount.CustomerID,
                    CustomerName = t.FixedDepositAccount.Customer.CustomerName
                });

            // Loan
            var loan = _db.LoanTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.LNAccountID,
                    AccountType = "Loan",
                    TransactionType = t.TransactionType ?? "EMI", // adapt if you use TransactionType
                    Amount = t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.LoanAccount.CustomerID,
                    CustomerName = t.LoanAccount.Customer.CustomerName
                });

            // union
            var union = savings.Union(fd).Union(loan);

            if (!string.IsNullOrEmpty(customerId))
            {
                union = union.Where(x => x.CustomerId == customerId);
            }

            if (!string.IsNullOrEmpty(category) && category != "ALL")
            {
                union = union.Where(x => x.AccountType == category);
            }

            // order and paging
            var ordered = union.OrderByDescending(x => x.TransactionDate);

            int skip = (page - 1) * pageSize;
            return ordered.Skip(skip).Take(pageSize).ToList();
        }

        // For export: returns all rows (be careful with size)
        public List<TransactionReportItem> GetTransactionReportForExport(DateTime? fromDate, DateTime? toDate,
                                                                         string category = "ALL", string customerId = null)
        {
            // same code but without Skip/Take
            DateTime from = fromDate ?? DateTime.MinValue;
            DateTime to = toDate?.Date.AddDays(1).AddTicks(-1) ?? DateTime.MaxValue;

            var savings = _db.SavingsTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.SBAccountID,
                    AccountType = "Savings",
                    TransactionType = t.TransactionType,
                    Amount = (decimal)t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.SavingsAccount.CustomerID,
                    CustomerName = t.SavingsAccount.Customer.CustomerName
                });

            var fd = _db.FixedDepositTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.FDAccountID,
                    AccountType = "Fixed Deposit",
                    TransactionType = t.TransactionType,
                    Amount = t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.FixedDepositAccount.CustomerID,
                    CustomerName = t.FixedDepositAccount.Customer.CustomerName
                });

            var loan = _db.LoanTransactions
                .Where(t => t.TransactionDate >= from && t.TransactionDate <= to)
                .Select(t => new TransactionReportItem
                {
                    TransactionId = t.TransactionID,
                    AccountId = t.LNAccountID,
                    AccountType = "Loan",
                    TransactionType = t.TransactionType ?? "EMI",
                    Amount = t.Amount,
                    TransactionDate = (DateTime)t.TransactionDate,
                    CustomerId = t.LoanAccount.CustomerID,
                    CustomerName = t.LoanAccount.Customer.CustomerName
                });

            var union = savings.Union(fd).Union(loan);

            if (!string.IsNullOrEmpty(customerId))
            {
                union = union.Where(x => x.CustomerId == customerId);
            }

            if (!string.IsNullOrEmpty(category) && category != "ALL")
            {
                union = union.Where(x => x.AccountType == category);
            }

            return union.OrderByDescending(x => x.TransactionDate).ToList();
        }
    }
}
