﻿using BankingAppDataAccess;
using BankingAppDataAccess.Repositories;
using BankingAppDomain.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingAppDomain.Services
{
    public class AccountService
    {
        private readonly BANKINGEntities db = new BANKINGEntities();
        private readonly AccountRepository _accRepo = new AccountRepository();
        private readonly CustomerRepository _custRepo = new CustomerRepository();
        static int age;
        private string GenerateAccountID(string accountType)
        {
            string prefix;
            switch (accountType.ToUpper())
            {
                case "SAVING": prefix = "SB"; break;
                case "FIXED-DEPOSIT": prefix = "FD"; break;
                case "LOAN": prefix = "LN"; break;
                default: prefix = "X"; break;
            }

            string newId;
            do
            {
                var rnd = new Random();
                newId = $"{prefix}{rnd.Next(0, 99999):D5}";
            }
            while (_accRepo.GetAccountById(newId) != null);

            return newId;
        }
        public void CloseAccount(string accountId)
        {
           var acc = _accRepo.GetAccountById(accountId);
            if(acc.AccountType == "SAVING")
            {
                var fd = _accRepo.GetOpenFDByCustomer(acc.CustomerID);
                var ln = _accRepo.GetOpenLoanByCustomer(acc.CustomerID);
                if(fd.Count > 0 || ln.Count > 0)
                {
                    throw new Exception("Account cannot be closed — customer has other active accounts.");
                }
            }

            _accRepo.UpdateAccountStatus(accountId, "CLOSED", DateTime.Now);
        }

        public List<Account> GetAllAccounts()
        {
            return _accRepo.GetAllAccounts();
        }


        public string CreateAccount(AccountTypeModel model)
        {

            Customer customer = _custRepo.GetCustomerFromId(model.Account.CustomerID);
            if (customer == null)
                return "Customer not found.";
            if (customer.DOB.HasValue)
            {
                age = DateTime.Today.Year - customer.DOB.Value.Year;

                if (customer.DOB.Value.Date > DateTime.Today.AddYears(-age))
                {
                    age--;
                }

            }
            if (customer.Status != "Active")
                return "Account cannot be opened — customer not ACTIVE.";

            
            switch (model.Account.AccountType.ToUpper())
            {
                case "SAVING":
                    if (model.savings.Balance < 1000)
                        return "Minimum opening balance is ₹1000.";
                    break;

                case "FIXED-DEPOSIT":
                    if (model.fixeddep.Amount < 10000)
                        return "Minimum FD amount is ₹10,000.";
                    break;

                case "LOAN":
                    if (model.loan.LoanAmount < 10000)
                        return "Minimum loan amount is ₹10,000.";
                    break;

                default:
                    return "Invalid account type.";
            }


            string accId = GenerateAccountID(model.Account.AccountType);

            // 5. Map Domain model → EF Entity
            var accEntity = new Account
            {
                AccountID = accId,
                AccountType = model.Account.AccountType.ToUpper(),
                CustomerID = model.Account.CustomerID,
                OpenedBy = model.Account.OpenedBy,
                OpenedByRole = model.Account.OpenedByRole,
                OpenDate = DateTime.Now,
                Status = "OPEN"
            };


            try
            {
                if (model.Account.AccountType.ToUpper() == "SAVING")
                {
                    if (_accRepo.GetSavingsByCustomer(accEntity.CustomerID).Count == 0)
                    {
                        var s = new SavingsAccount
                        {
                            SBAccountID = accId,
                            CustomerID = model.Account.CustomerID,
                            Balance = model.savings.Balance
                        };

                        db.Accounts.Add(accEntity);
                        db.SavingsAccounts.Add(s);
                        db.SaveChanges();

                    }
                    else
                    {
                        return "Customer already has a Savings Account.";
                    }
                }
                else if (model.Account.AccountType.ToUpper() == "FIXED-DEPOSIT")
                {
                    if (_accRepo.GetSavingsByCustomer(accEntity.CustomerID).Count > 0)
                    {
                        double time = (model.fixeddep.EndDate - model.fixeddep.StartDate).TotalDays / 365;
                        double mat = (double)model.fixeddep.Amount;
                        if (time <= 1)
                        {
                            mat *= Math.Pow(1 + 0.06, time);
                        }
                        else if (time <= 2)
                        {
                            mat *= Math.Pow(1 + 0.06, 1);
                            mat *= Math.Pow(1 + 0.07, time - 1);
                        }
                        else
                        {
                            mat *= Math.Pow(1 + 0.06, 1);
                            mat *= Math.Pow(1 + 0.07, 1);
                            mat *= Math.Pow(1 + 0.08, time - 2);
                        }
                        if (time <= 1)
                        {
                            model.fixeddep.FD_ROI = 6;
                        }
                        else if (time <= 2)
                        {
                            model.fixeddep.FD_ROI = 7;
                        }
                        else
                        {
                            model.fixeddep.FD_ROI = 8;
                        }

                        if (age >= 60)
                        {
                            mat = (0.05 * mat) + mat;
                        }
                        model.fixeddep.MaturityAmount1 = Math.Round((decimal)mat, 2);
                        model.fixeddep.FDAccountID = accId;
                        model.fixeddep.CustomerID = model.Account.CustomerID;
                        //FixedDepositAccount f = new FixedDepositAccount
                        //{
                        //    FDAccountID = accId,
                        //    CustomerID = model.Account.CustomerID,
                        //    Amount = model.fixeddep.Amount,
                        //    StartDate = model.fixeddep.StartDate,
                        //    EndDate = model.fixeddep.EndDate,
                        //    FD_ROI = model.fixeddep.FD_ROI,
                        //    MaturityAmount = (decimal)model.fixeddep.MaturityAmount
                        //};
                        db.Accounts.Add(accEntity);
                        db.FixedDepositAccounts.Add(model.fixeddep);
                        db.SaveChanges();

                    }
                    else
                    {
                        return "Customer must have a Savings Account to open a Fixed Deposit.";
                    }

                }
                else if (model.Account.AccountType.ToUpper() == "LOAN")
                {

                    if (_accRepo.GetSavingsByCustomer(accEntity.CustomerID).Count > 0)
                    {
                        var l = new LoanAccount
                        {
                            LNAccountID = accId,
                            CustomerID = model.Account.CustomerID,
                            LoanAmount = model.loan.LoanAmount,
                            StartDate = model.loan.StartDate,
                            TenureMonths = model.loan.TenureMonths,
                            LN_ROI = model.loan.LN_ROI,
                            EMI = model.loan.EMI,
                            Outstanding = model.loan.Outstanding,
                            NextDueDate = DateTime.Now.AddMonths(1)
                        };
                        db.Accounts.Add(accEntity);
                        db.LoanAccounts.Add(l);
                        db.SaveChanges();
                    }
                    else
                    {
                        return "Customer must have a Savings Account to open a Loan Account.";
                    }
                }
            }
            catch (DbEntityValidationException ex)
            {
                var errorMessages = new List<string>();

                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var error in validationErrors.ValidationErrors)
                    {
                        errorMessages.Add($"Property: {error.PropertyName}, Error: {error.ErrorMessage}");
                    }
                }

                var fullErrorMessage = string.Join("; ", errorMessages);
                var exceptionMessage = $"Validation Errors: {fullErrorMessage}";

                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }


            return $"Account created successfully with ID {accId}.";
        }

        public LoanAccount GetLoanAcc(string id)
        {
            return _accRepo.GetLoanById(id);
        }

        public List<AccTransaction> GetAllAccTransById(string id)
        {
            SavingsAccount Sav = _accRepo.GetSavingsByCust(id);
            List<AccTransaction> accTrans = _accRepo.GetAllAccTrans(Sav.SBAccountID);
            return accTrans;
        }
    }
}
