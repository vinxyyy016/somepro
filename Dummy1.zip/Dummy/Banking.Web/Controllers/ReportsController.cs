﻿using BankingAppDomain.Services;
using ClosedXML.Excel;
using Rotativa;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Banking.Web.Controllers
{
    public class ReportsController : Controller
    {
        private readonly ReportService _reports = new ReportService();
        [HttpGet]
        public ActionResult TransactionReport(DateTime? fromDate, DateTime? toDate, string category = "ALL",
                                              string customerId = null, int page = 1, int pageSize = 100)
        {
            if (Session["Role"].ToString() == "Customer")
            {
                customerId = Session["UserID"].ToString();
            }
            var data = _reports.GetTransactionReport(fromDate, toDate, category, customerId, page, pageSize);
            ViewBag.FromDate = fromDate?.ToString("yyyy-MM-dd");
            ViewBag.ToDate = toDate?.ToString("yyyy-MM-dd");
            ViewBag.Category = category;
            ViewBag.CustomerId = customerId;
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;

            return View($"~/Views/{Session["Role"]}/TransactionReport.cshtml",data);
        }

        // Export to Excel
        [HttpGet]
        public ActionResult ExportTransactionReportToExcel(DateTime? fromDate, DateTime? toDate, string category = "ALL", string customerId = null)
        {
            var list = _reports.GetTransactionReportForExport(fromDate, toDate, category, customerId);

            using (var workbook = new XLWorkbook())
            {
                var ws = workbook.Worksheets.Add("Transactions");
                // header
                ws.Cell(1, 1).Value = "TransactionId";
                ws.Cell(1, 2).Value = "AccountId";
                ws.Cell(1, 3).Value = "AccountType";
                ws.Cell(1, 4).Value = "TransactionType";
                ws.Cell(1, 5).Value = "Amount";
                ws.Cell(1, 6).Value = "TransactionDate";
                ws.Cell(1, 7).Value = "CustomerId";
                ws.Cell(1, 8).Value = "CustomerName";

                int r = 2;
                foreach (var it in list)
                {
                    ws.Cell(r, 1).Value = it.TransactionId;
                    ws.Cell(r, 2).Value = it.AccountId;
                    ws.Cell(r, 3).Value = it.AccountType;
                    ws.Cell(r, 4).Value = it.TransactionType;
                    ws.Cell(r, 5).Value = it.Amount;
                    ws.Cell(r, 6).Value = it.TransactionDate;
                    ws.Cell(r, 7).Value = it.CustomerId;
                    ws.Cell(r, 8).Value = it.CustomerName;
                    r++;
                }

                ws.Columns().AdjustToContents();

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    stream.Seek(0, SeekOrigin.Begin);
                    string fileName = $"TransactionReport_{DateTime.Now:yyyyMMddHHmmss}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }
            }
        }

        // Export to PDF via Rotativa (render a view to HTML and convert)
        [HttpGet]
        public ActionResult ExportTransactionReportToPdf(DateTime? fromDate, DateTime? toDate, string category = "ALL", string customerId = null)
        {
            var list = _reports.GetTransactionReportForExport(fromDate, toDate, category, customerId);
            // Create a simple HTML view for PDF or reuse the TransactionReport view
            var vm = list; // you can pass list to a dedicated view
            return new ViewAsPdf("TransactionReportPdf", vm) // create TransactionReportPdf.cshtml
            {
                FileName = $"TransactionReport_{DateTime.Now:yyyyMMddHHmmss}.pdf",
                PageSize = Rotativa.Options.Size.A4
            };
        }
    }
}